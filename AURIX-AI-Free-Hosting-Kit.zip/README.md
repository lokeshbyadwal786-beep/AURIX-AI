# AURIX AI Free Hosting Kit

## Deploy with Render from a phone
1. Upload `main.py`, `requirements.txt`, and `render.yaml` to the root of the GitHub repository.
2. Open https://render.com and sign in with GitHub.
3. Choose New -> Blueprint and select `lokeshbyadwal786-beep/AURIX-AI`.
4. Review the service and create it. Render will ask for `DATABASE_URL` and `OPENAI_API_KEY`.
5. For a quick temporary demo, `DATABASE_URL` may be left unset only if the dashboard allows it; the app then uses local SQLite, whose data may be lost on free instance restart/redeploy. For persistent accounts/memory, create a PostgreSQL database (for example a free tier provider) and set its connection string.
6. Set `OPENAI_API_KEY` only if you want real GPT chat. Keep it private and enter it only in Render environment variables, never in GitHub files or the Android app.
7. When deploy succeeds, test `https://YOUR-SERVICE.onrender.com/health`. It should return `{"status":"ok","service":"aurix-api"}`.

## Important
- Free web instances may sleep when idle and cold-start slowly.
- Free hosting quotas and database terms can change; check the provider dashboard before creating resources.
- This starter currently supports OpenAI chat only; other model providers, Google OAuth, rate limits, email verification, password reset, migrations and production monitoring are not implemented.
- Do not use this demo with sensitive personal data before production security review.
- The APK built earlier still points to the Android emulator address `10.0.2.2`. After deployment, replace `AURIX_API_BASE_URL` in `android/app/build.gradle.kts` with your HTTPS Render URL and rebuild the APK in GitHub Actions.
