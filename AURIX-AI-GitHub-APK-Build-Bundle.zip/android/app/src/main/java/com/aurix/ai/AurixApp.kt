package com.aurix.ai

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun AurixApp(api: AurixApi, vault: TokenVault, requestMic: (() -> Unit) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var token by remember { mutableStateOf(vault.read()) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    var language by remember { mutableStateOf("hi") }
    var provider by remember { mutableStateOf("openai") }
    var gender by remember { mutableStateOf("female") }
    var input by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("AURIX online") }
    var busy by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<Pair<String, Boolean>>() }
    val voice = remember {
        VoiceController(context, { input = it }, { status = it })
    }
    DisposableEffect(Unit) { onDispose { voice.release() } }
    LaunchedEffect(language, gender) { voice.configure(language, gender) }

    val bg = Brush.verticalGradient(listOf(Color(0xFF0C2038), Color(0xFF070D18), Color(0xFF050911)))
    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF070D18)) {
        Column(Modifier.fillMaxSize().background(bg).padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Color(0xFF0C80AD), RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                    Text("A", color = Color.White, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("A U R I X", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("PERSONAL AI SYSTEM", color = Color(0xFF75A9C9), style = MaterialTheme.typography.labelSmall)
                }
                Text(status, color = Color(0xFF62DDF4), style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(18.dp))
            if (token.isNullOrBlank()) {
                Text(if (register) "Create account" else "Welcome back", color = Color.White, style = MaterialTheme.typography.headlineSmall)
                OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(password, { password = it }, label = { Text("Password (10+ characters)") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth(), singleLine = true)
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    scope.launch {
                        busy = true
                        try { val newToken = api.authenticate(email.trim(), password, register); vault.save(newToken); token = newToken; status = "Logged in" }
                        catch (e: Exception) { status = e.message ?: "Login failed" }
                        finally { busy = false }
                    }
                }, enabled = !busy && email.isNotBlank() && password.length >= 10, modifier = Modifier.fillMaxWidth()) {
                    Text(if (busy) "Please wait…" else if (register) "Register" else "Login")
                }
                TextButton(onClick = { register = !register }) { Text(if (register) "Already have an account? Login" else "New here? Create account") }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("AI CONSOLE", color = Color(0xFF74B6D6), style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                    TextButton(onClick = { vault.clear(); token = null; messages.clear() }) { Text("Logout") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = language == "hi", onClick = { language = "hi" }, label = { Text("हिन्दी") })
                    FilterChip(selected = language == "en", onClick = { language = "en" }, label = { Text("English") })
                    Spacer(Modifier.weight(1f))
                    var menu by remember { mutableStateOf(false) }
                    Box {
                        TextButton(onClick = { menu = true }) { Text(provider.uppercase()) }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            listOf("openai","gemini","claude").forEach { item ->
                                DropdownMenuItem(text = { Text(item.uppercase()) }, onClick = { provider = item; menu = false })
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = gender == "female", onClick = { gender = "female" }, label = { Text("Female voice") })
                    FilterChip(selected = gender == "male", onClick = { gender = "male" }, label = { Text("Male voice") })
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    if (messages.isEmpty()) item {
                        Text("नमस्ते! मैं AURIX हूँ। बोलें या अपना सवाल लिखें।", color = Color(0xFFB9D6EA), modifier = Modifier.padding(8.dp))
                    }
                    items(messages) { item ->
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = if (item.second) Alignment.End else Alignment.Start) {
                            Surface(color = if (item.second) Color(0xFF123B58) else Color(0xFF142235), shape = RoundedCornerShape(14.dp)) {
                                Text(item.first, color = Color.White, modifier = Modifier.padding(12.dp))
                            }
                        }
                    }
                }
                OutlinedTextField(input, { input = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Message AURIX") })
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = {
                        requestMic { voice.startListening() }
                    }) { Text("🎙 Speak") }
                    Button(onClick = {
                        val message = input.trim()
                        if (message.isNotEmpty() && !busy) {
                            messages.add(message to true); input = ""; busy = true; status = "Thinking…"
                            scope.launch {
                                try {
                                    val result = api.chat(message, language, provider, token!!)
                                    messages.add(result.reply to false); voice.speak(result.reply); status = "Speaking"
                                } catch (e: Exception) { messages.add((e.message ?: "Request failed") to false); status = "Error" }
                                finally { busy = false }
                            }
                        }
                    }, enabled = input.isNotBlank() && !busy, modifier = Modifier.weight(1f)) { Text(if (busy) "Thinking…" else "Send") }
                    OutlinedButton(onClick = { voice.stopSpeaking(); status = "Ready" }) { Text("Stop") }
                }
                Spacer(Modifier.height(5.dp))
                Text("Mic starts only when you tap Speak. Transcript is sent only after Send.", color = Color(0xFF7895AE), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
