package com.aurix.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatResult(val reply: String)

class AurixApi(baseUrl: String) {
    private val base = baseUrl.trimEnd('/')
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private suspend fun post(path: String, payload: JSONObject, token: String? = null): JSONObject =
        withContext(Dispatchers.IO) {
            val builder = Request.Builder().url("$base$path")
                .post(payload.toString().toRequestBody(jsonType))
                .header("Accept", "application/json")
            if (!token.isNullOrBlank()) builder.header("Authorization", "Bearer $token")
            http.newCall(builder.build()).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val detail = try { JSONObject(body).optString("detail", response.message) } catch (_: Exception) { response.message }
                    throw IllegalStateException("HTTP ${response.code}: $detail")
                }
                JSONObject(body)
            }
        }

    suspend fun authenticate(email: String, password: String, register: Boolean): String {
        val result = post(
            if (register) "/v1/auth/register" else "/v1/auth/login",
            JSONObject().put("email", email).put("password", password)
        )
        return result.getString("access_token")
    }

    suspend fun chat(message: String, language: String, provider: String, token: String): ChatResult {
        val result = post("/v1/chat", JSONObject()
            .put("message", message).put("language", language).put("provider", provider), token)
        return ChatResult(result.optString("reply", "No response received."))
    }

    suspend fun memoryConsent(enabled: Boolean, token: String): Boolean {
        val result = post("/v1/memory/consent", JSONObject().put("enabled", enabled), token)
        return result.optBoolean("enabled", false)
    }
}
