package com.aurix.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private var permissionGranted: (() -> Unit)? = null
    private val requestMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) permissionGranted?.invoke()
        permissionGranted = null
    }

    fun withMicrophonePermission(onGranted: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            onGranted()
        } else {
            permissionGranted = onGranted
            requestMic.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val vault = TokenVault(applicationContext)
        val api = AurixApi(BuildConfig.AURIX_API_BASE_URL)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF38D9F5),
                background = Color(0xFF070D18),
                surface = Color(0xFF101D2E)
            )) {
                AurixApp(api = api, vault = vault, requestMic = ::withMicrophonePermission)
            }
        }
    }
}
