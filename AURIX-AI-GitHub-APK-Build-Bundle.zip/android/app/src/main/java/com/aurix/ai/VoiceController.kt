package com.aurix.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class VoiceController(
    private val context: Context,
    private val onText: (String) -> Unit,
    private val onStatus: (String) -> Unit
) : RecognitionListener, TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var language = "hi-IN"
    private var voiceGender = "female"

    init { tts = TextToSpeech(context, this) }

    fun configure(languageCode: String, gender: String) {
        language = if (languageCode == "en") "en-IN" else "hi-IN"
        voiceGender = gender
        tts?.language = Locale.forLanguageTag(language)
        selectVoice()
    }

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onStatus("Speech recognition is not available on this device.")
            return
        }
        stopListening()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context).also { it.setRecognitionListener(this) }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        onStatus("Listening…")
        recognizer?.startListening(intent)
    }

    fun stopListening() {
        recognizer?.stopListening()
        recognizer?.destroy()
        recognizer = null
    }

    fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "aurix_reply")
    }

    fun stopSpeaking() { tts?.stop() }

    private fun selectVoice() {
        val voices = tts?.voices ?: return
        val candidates = voices.filter { it.locale.language == Locale.forLanguageTag(language).language }
        val desired = if (voiceGender == "female") listOf("female","woman","zira","samantha","heera") else listOf("male","man","david","mark")
        val match = candidates.firstOrNull { v -> desired.any { v.name.lowercase().contains(it) } }
        if (match != null) tts?.voice = match
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.forLanguageTag(language)
            selectVoice()
        }
    }
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() { onStatus("Ready") }
    override fun onError(error: Int) { onStatus("Voice error: $error") }
    override fun onResults(results: Bundle?) {
        val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!spoken.isNullOrBlank()) onText(spoken)
        onStatus("Ready")
    }
    override fun onPartialResults(partialResults: Bundle?) {
        val spoken = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!spoken.isNullOrBlank()) onText(spoken)
    }
    override fun onEvent(eventType: Int, params: Bundle?) {}

    fun release() {
        stopListening()
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
