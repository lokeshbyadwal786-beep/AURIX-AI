# AURIX AI GitHub APK build bundle

Upload the contents of this folder to the root of your GitHub repository (not the folder itself).
After committing to `main`, GitHub Actions will build a debug APK.

To download:
1. Open the repository's Actions tab.
2. Select "Build AURIX AI Android APK".
3. Open the latest successful run.
4. In Artifacts, download `aurix-ai-debug-apk`.
5. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

This is an unsigned debug APK for testing, not a Play Store release.
The workflow uses GitHub Actions hosted runners. Public repositories generally have
free standard-runner usage; private repositories have plan-based minute/storage limits.
